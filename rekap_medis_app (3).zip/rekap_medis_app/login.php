<?php
session_start(); // <-- TAMBAHKAN BARIS INI DI SINI

// login.php
require_once 'config.php';

$username = $password = "";
$username_err = $password_err = $login_err = "";

// Memproses data form saat form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validasi username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Mohon masukkan Username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Validasi password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Mohon masukkan password Anda.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Cek kredensial
    if (empty($username_err) && empty($password_err)) {
        $sql = "SELECT id, username, password, nama_lengkap, role FROM users WHERE username = ?";

        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $param_username);
            $param_username = $username;

            if ($stmt->execute()) {
                $stmt->store_result();

                // Cek jika username ada, lalu verifikasi password
                if ($stmt->num_rows == 1) {
                    $stmt->bind_result($id, $username_db, $hashed_password_db, $nama_lengkap, $role);
                    if ($stmt->fetch()) {
                        if (password_verify($password, $hashed_password_db)) {
                            // Password benar, simpan data di session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username_db;
                            $_SESSION["nama_lengkap"] = $nama_lengkap;
                            $_SESSION["role"] = $role;

                            // Redirect ke halaman dashboard
                            header("location: dashboard.php");
                            exit;
                        } else {
                            $login_err = "Username atau Password salah.";
                        }
                    }
                } else {
                    $login_err = "Username atau Password salah.";
                }
            } else {
                echo "Ada yang salah. Silakan coba lagi nanti.";
            }

            $stmt->close();
        } else {
            echo "Gagal menyiapkan statement SQL: " . $conn->error;
        }
    }
}
// Pindahkan penutupan koneksi ke sini, atau biarkan PHP menutupnya secara otomatis
$conn->close(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Rekap Medis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #e0f2f7; /* Warna biru muda */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .login-container {
            display: flex;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 90%;
            max-width: 1200px;
        }
        .login-left {
            background-color: #1a237e; /* Biru tua */
            color: #fff;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            width: 50%;
            position: relative;
            background-image: url('assets/dokter.png.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .login-left::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(26, 35, 126, 0.8); /* Overlay gelap */
            border-radius: 15px 0 0 15px;
        }
        .login-left-content {
            z-index: 1;
        }
        .login-left h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }
        .logo-rekap-medis {
            width: 300px; /* <--- UKURAN LOGO TELAH DIUBAH DI SINI */
            height: auto;
            margin-bottom: 10x; /* Mengurangi sedikit margin-bottom agar lebih rapat */
        }
        .login-left ul {
            list-style: none;
            padding: 0;
            text-align: left;
            margin-top: 0px;
        }
        .login-left ul li {
            margin-bottom: 15px;
            font-size: 1.1rem;
            color:#fff;
        }
        .login-left ul li i {
            margin-right: 10px;
            color: #64b5f6; /* Warna ikon */
        }
        .login-right {
            padding: 40px;
            width: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .login-right h2 {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #333;
            text-align: center;
        }
        .login-right p {
            color: #666;
            margin-bottom: 30px;
            text-align: center;
        }
        .form-floating label {
            color: #6c757d;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
            border-radius: 10px;
            padding: 12px;
            font-size: 1.1rem;
            width: 100%;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            height: auto; /* Mengatur tinggi secara otomatis */
        }
        .form-check-label {
            color: #666;
        }
        .text-danger {
            font-size: 0.9em;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group .input-group-text {
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
            background-color: #e9ecef;
            border-right: none;
        }
        .form-group .form-control {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
            border-left: none;
        }
        .password-toggle {
            cursor: pointer;
            padding: 0.375rem 0.75rem;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            background-color: #e9ecef;
            border: 1px solid #ced4da;
            border-left: none;
            display: flex;
            align-items: center;
            color: #6c757d;
        }
        .password-input-container {
            display: flex;
            width: 100%;
        }
        .form-group .input-group {
            border-radius: 10px;
            overflow: hidden; /* agar border radius terlihat */
        }
        .form-group .input-group > .form-control {
            border-radius: 10px; /* Reset border-radius untuk input agar penuh */
        }
        .form-group .input-group:focus-within {
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,.25);
            border-color: #86b7fe;
        }
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                width: 95%;
            }
            .login-left, .login-right {
                width: 100%;
                padding: 30px;
            }
            .login-left {
                border-radius: 15px 15px 0 0;
            }
            .login-left::before {
                border-radius: 15px 15px 0 0;
            }
            .login-right {
                border-radius: 0 0 15px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-left">
            <div class="login-left-content">
                <img src="assets/logo1.png" alt="Logo Rekap Medis" class="logo-rekap-medis">
                <ul>
                    <li><strong>nama peserta : ahlil mustofa bidin</strong></li>
                   
                </ul>
            </div>
        </div>
        <div class="login-right">
            <h2>Masuk ke Sistem</h2>
            <p>Gunakan akun resmi rumah sakit Anda</p>

            <?php
            if (!empty($login_err)) {
                echo '<div class="alert alert-danger mb-4">' . $login_err . '</div>';
            }
            ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" name="username" id="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>" placeholder="Masukkan username Anda">
                        <?php if (!empty($username_err)): ?>
                            <div class="invalid-feedback"><?php echo $username_err; ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group password-input-container">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" id="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" placeholder="Masukkan password">
                        <span class="password-toggle" onclick="togglePasswordVisibility()">
                            <i class="fas fa-eye" id="password-toggle-icon"></i>
                        </span>
                        <?php if (!empty($password_err)): ?>
                            <div class="invalid-feedback"><?php echo $password_err; ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe">
                    <label class="form-check-label" for="rememberMe">Ingat perangkat ini</label>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-2"></i> Masuk
                    </button>
                </div>
                <div class="text-center mt-3">
                    <a href="#" class="text-decoration-none">Lupa password?</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
    <script>
        // Fungsi untuk toggle visibilitas password
        function togglePasswordVisibility() {
            const passwordField = document.getElementById('password');
            const passwordToggleIcon = document.getElementById('password-toggle-icon');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordToggleIcon.classList.remove('fa-eye');
                passwordToggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordToggleIcon.classList.remove('fa-eye-slash');
                passwordToggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>