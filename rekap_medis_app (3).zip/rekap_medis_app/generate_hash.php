<?php
// generate_hash_combined.php
// File ini digunakan untuk menghasilkan hash password yang aman.
// Anda bisa menjalankan file ini di browser Anda, menyalin output hash-nya,
// dan menempelkannya ke kolom 'password' di tabel 'users' di phpMyAdmin.
// Pastikan drop-down 'Function' di phpMyAdmin diatur ke '-- none --' saat menempel hash.


// --- Bagian 1: Hash untuk 'password123' (dari kode Anda sebelumnya) ---
$password_to_hash = 'password123'; // Password plain text pertama
$hashed_password = password_hash($password_to_hash, PASSWORD_DEFAULT);
echo "Password Plain Text (password123): " . htmlspecialchars($password_to_hash) . "<br>";
echo "Hashed password (password123): <br><strong>" . htmlspecialchars($hashed_password) . "</strong><br><br>";


// --- Bagian 2: Hash untuk '13082022' (custom password yang Anda minta) ---
$my_custom_password = '13082022'; // Password plain text kustom yang Anda inginkan
$hashed_my_custom_password = password_hash($my_custom_password, PASSWORD_DEFAULT);
echo "Password Plain Text (13082022): " . htmlspecialchars($my_custom_password) . "<br>";
echo "Hashed password (13082022): <br><strong>" . htmlspecialchars($hashed_my_custom_password) . "</strong><br><br>";


// --- Bagian 3: Hash untuk '23082012' (dari kode Anda sebelumnya) ---
$another_custom_password = '23082012'; // Password lain dari kode Anda
$hashed_another_custom_password = password_hash($another_custom_password, PASSWORD_DEFAULT);
echo "Password Plain Text (23082012): " . htmlspecialchars($another_custom_password) . "<br>";
echo "Hashed password (23082012): <br><strong>" . htmlspecialchars($hashed_another_custom_password) . "</strong><br><br>";

echo "<hr>";
echo "<h3>Instruksi:</h3>";
echo "<p>1. Salin seluruh string hash yang panjang untuk password yang Anda inginkan.</p>";
echo "<p>2. Buka phpMyAdmin, navigasikan ke database 'rekap_medis', tabel 'users'.</p>";
echo "<p>3. Edit pengguna yang ingin Anda ubah password-nya.</p>";
echo "<p>4. Tempelkan string hash yang Anda salin ke kolom 'password'.</p>";
echo "<p>5. Pastikan kolom 'Function' (Fungsi) di samping kolom 'password' diatur ke <strong>-- none --</strong> atau dikosongkan.</p>";
echo "<p>6. Simpan perubahan.</p>";
echo "<p>7. Restart Apache di XAMPP Control Panel.</p>";
echo "<p>8. Coba login dengan password plain text asli (misalnya, '13082022') di aplikasi Anda.</p>";
?>
